
package main;

import java.util.Scanner;
import java.util.regex.Pattern;

/**
 *
 * @author Lujain
 */
public class Main {

    static int choice; // user when run program will should choose one choice from register and login
    static Users users = new Users();
    static Rental rent = new Rental();
    static Scanner sc = new Scanner(System.in);
    private static Pattern pattern = Pattern.compile("-?\\d+(\\.\\d+)?");
    static int RentalDays, Mileage;
    static String passengers;
    
      
    
    public static void main(String[] args) {
        
        
        //ask info from user
      
       

do {
    System.out.println("#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#");
    System.out.println("A car rental application");
    System.out.println("We will help you to find the cheapest car rental base on car rental price and gas mileage\n");
    System.out.println("#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#");
    System.out.println(" TO REGISTER ENTER (1)");
    System.out.println(" TO LOGIN ENTER (2)");
    System.out.println(" TO EXIT (3)\n");
    System.out.print("Enter your choice: ");

    String temp = sc.next();
    
    if(pattern.matcher(temp).matches()){
        choice = Integer.parseInt(temp);
    }else{
        System.out.println("Invalid option, Try again!!");
        continue;
    }
    

    switch (choice) {
        case 1:
            users.register();
            rent.rental();
            break;
        case 2:
            if (users.login()) {
                rent.rental();
                
            }
            break;
        case 3:
            break;
        default:
            System.out.println("Invalid option, Try again!!");
    }

} while (choice != 3);
}
}       

