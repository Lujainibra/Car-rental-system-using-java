
package main;

/**
 *
 * @author Lujain
 */
public class Car {

   protected String carModel;
    protected int rentalCost = 0;
    protected String maxPassengers;
    protected String comfortLevel = null;

    public Car(){}
    
    public Car(String carModel, int rentalCost, String maxPassengers, String comfortLevel) {
        this.carModel = carModel;
        this.comfortLevel = comfortLevel;
        this.maxPassengers = maxPassengers;
        this.rentalCost = rentalCost;
    }
    protected String getCarModel() {
        return carModel;
    }
    protected void setCarModel(String carModel) {
        this.carModel = carModel;
    }
    protected String getMaxPassengers() {
        return maxPassengers;
    }
    protected void setMaxPassengers(String maxPassengers) {
        this.maxPassengers = maxPassengers;
    }
    protected String getComfortLevel() {
        return comfortLevel;
    }
    protected void setComfortLevel(String comfortLevel) {
        this.comfortLevel = comfortLevel;
    }
    protected int getRentalCost(){
        return rentalCost;
    }
    protected void setRentalCost(int rentalCost){
        this.rentalCost = rentalCost;
    }
}