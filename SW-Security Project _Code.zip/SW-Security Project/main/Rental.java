package main;

import java.util.ArrayList;
import java.util.Scanner;
import java.util.regex.Pattern;



public class Rental {
   
    static Scanner sc = new Scanner(System.in);
    static Pattern pattern = Pattern.compile("-?\\d+(\\.\\d+)?");
    static int RentalDays, Mileage;
    static String passengers;

    //StandardCar
    Car suv = new StandardCar("SUV",55, "5", "Good");
    Car crossover = new StandardCar("Crossover",55, "5", "Good");
    Car truck = new StandardCar("Truck",55, "5", "Good");

    //EconomyCar
    Car coupe = new EconomyCar("Coupe",45, "4", "Poor");

    //IntermediateCar
    Car sedan = new IntermediateCar("Sedan",50, "4", "Medium");
    Car hybrid = new IntermediateCar("Hybrid",50, "4", "Medium");

    //VanCar
    Car van_Minivan = new VanCar("Van/Minivan",70, "7", "Medium");

    //Array of cars Category
    Car carsCategory[] = {suv, crossover, truck, coupe, sedan, hybrid, van_Minivan};


       protected double distance(double Mileage) {
        final double gallons = 2.25;
         return Mileage * gallons;
     }
     
        protected ArrayList findCar(String passengers, Car carsCategory[]){
         ArrayList<Car> matchCar = new ArrayList<Car>();
         double rentCost = 100;
         for (int index=0; index<carsCategory.length; index++){
             if (carsCategory[index].getMaxPassengers().equals(passengers)){
                 if (carsCategory[index].getRentalCost() <= rentCost){
                     rentCost = carsCategory[index].getRentalCost();
                     matchCar.add(carsCategory[index]);
                 }
             }
         }
         return matchCar;
     }



     protected void rental() {


    System.out.print("1.) Please enter number of passengers : Enter (4 or 5 or 7) ");
    passengers = sc.next();
    while( !( passengers.equals("4") || passengers.equals("5") || passengers.equals("7") ) ){
        System.out.println("You have entered wrong Input. Please enter (4 or 5 or 7) ");
        passengers = sc.next();
    }
    System.out.print("2.) Please enter number of rental days :");
    RentalDays = sc.nextInt();
    System.out.print("3.) Please enter number of mileage for the trip :");
    Mileage = sc.nextInt();
    
    //the result
    System.out.println();
    System.out.println("The Matching Car:");
    System.out.println();
    final ArrayList<Car> matchCar = findCar(passengers, carsCategory);
    int Rental_Cost=0;
    for(Car car:matchCar) {
        System.out.println(car);
        Rental_Cost = car.getRentalCost();
    }
    System.out.println();
    System.out.println("The trip cost would be $" + ( (Rental_Cost*RentalDays) + distance(Mileage) ) );
    
}
}

