package main;
  
import java.util.Scanner;


public class Accaunt {  

    static Scanner sc = new Scanner(System.in);
    private String username;
    private String password;
    private String email;
    private String name;
    private int phone;

// getter and setter 
    protected String getUsername() {
        return username;
    }

    protected void setUsername(String username) {
        this.username = username;
    }

    protected String getPassword() {
        return password;
    }

    protected void setPassword(String password) {
        this.password = password;
    }

    protected String getEmail() {
        return email;
    }

    protected void setEmail(String email) {
        this.email = email;
    }

    protected String getName() {
        return name;
    }

    protected void setName(String name) {
        this.name = name;
    }

    protected int getPhone() {
        return phone;
    }

    protected void setPhone(int phone) {
        this.phone = phone;
    }
}




