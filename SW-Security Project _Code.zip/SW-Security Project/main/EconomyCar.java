
package main;

/**
 *
 * @author Lujain
 */
public class EconomyCar extends Car {

    public EconomyCar(String carModel,int rentalCost, String maxPassengers, String comfortLevel) {
        super(carModel,rentalCost, maxPassengers, comfortLevel);
    }


      @Override
    public String toString() {
        return "Car Model "+super.carModel+", " +"Rental Cost: $" + super.rentalCost +", " + "Maximun Passangers: " + super.maxPassengers +", " + "Comfort Level: " + super.comfortLevel + ".";

    }

}

